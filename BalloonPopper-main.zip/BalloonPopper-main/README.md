# BalloonPopper

Steps to start:

1.Open command prompt or visual studio terminal.</br>
2.Type 'cd balloonPopper'.</br>
4.Install Expo go in smartphone.</br>
5.Make sure both system and smartphone are connected to same wifi.\</br>
3.Type 'npx expo start'.</br>
4.Scan Qr code or type url.</br>
